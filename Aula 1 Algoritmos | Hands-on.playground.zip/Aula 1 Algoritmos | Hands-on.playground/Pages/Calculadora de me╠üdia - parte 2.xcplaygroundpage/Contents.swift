/*:
 # Calculadora de média - parte 2
 
 Você lembra daquele programa que fizemos para calcular a média do João na semana passada né? Mas acontece que o professor pediu para que você expandisse aquele programa, pra que ele possa usar com qualquer aluno.
 
 A ideia dele é a seguinte:
 
 - O professor deve inserir o nome do aluno e as notas dos 4 bimestres do aluno ao iniciar o programa
 - O programa deve fazer o cálculo da média das notas
 - Se a média do aluno for maior que 7.5, o aluno está aprovado. Do contrário, o aluno está reprovado.
 - Tendo essas informações, o sistema deve retornar uma mensagem dizendo: "O \(aluno) foi \(aprovacao) com nota \(media)".
 
 Faça seu programa nas linhas abaixo.
 *
*/

func calcularMedia(_ aluno:String, _ nota1:Double,_ nota2:Double,_ nota3:Double,_ nota4:Double) -> String {
    
    let media = (nota1 + nota2 + nota3 + nota4) / 4;
    
    let aprovado = media > 7.5 ? "aprovado" : "reprovado";
    
    return "O \(aluno) foi \(aprovado) com nota \(media)";
}


calcularMedia("João", 5.0, 7.0, 6.0, 8.0)
